#! /bin/bash
python3 runner.py