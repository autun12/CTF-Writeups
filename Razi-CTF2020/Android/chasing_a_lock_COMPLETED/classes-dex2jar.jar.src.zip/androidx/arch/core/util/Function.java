package androidx.arch.core.util;

public interface Function<I, O> {
  O apply(I paramI);
}


/* Location:              /home/austin/Documents/CTFFolder/CTF-Writeups/Razi-CTF2020/Android/chasing_a_lock/chasing a lock/classes-dex2jar.jar!/androidx/arch/core/util/Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */