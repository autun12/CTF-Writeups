package androidx.constraintlayout.widget;

public abstract class ConstraintsChangedListener {
  public void postLayoutChange(int paramInt1, int paramInt2) {}
  
  public void preLayoutChange(int paramInt1, int paramInt2) {}
}


/* Location:              /home/austin/Documents/CTFFolder/CTF-Writeups/Razi-CTF2020/Android/chasing_a_lock/chasing a lock/classes-dex2jar.jar!/androidx/constraintlayout/widget/ConstraintsChangedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */