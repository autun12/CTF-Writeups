package androidx.constraintlayout.solver.widgets.analyzer;

public interface Dependency {
  void update(Dependency paramDependency);
}


/* Location:              /home/austin/Documents/CTFFolder/CTF-Writeups/Razi-CTF2020/Android/chasing_a_lock/chasing a lock/classes-dex2jar.jar!/androidx/constraintlayout/solver/widgets/analyzer/Dependency.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */