# CS_ARCH_AARCH64, None, None
# This regression test file is new. The option flags could not be determined.
# LLVM uses the following mattr = []
0x02 == compact encoding:     0x02000000
0x02 == compact encoding:     0x02009000
0x02 == compact encoding:     0x0200400f
0x02 == compact encoding:     0x02021010
