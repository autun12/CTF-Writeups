# CS_ARCH_AARCH64, None, None
# This regression test file is new. The option flags could not be determined.
# LLVM uses the following mattr = []
0x7b 0xbf 0x25 0x72 == invalid instruction encoding
