# CS_ARCH_AARCH64, None, None
# This regression test file is new. The option flags could not be determined.
# LLVM uses the following mattr = []
0x03 == compact encoding:     0x03000000
0x03 == compact encoding:     0x03000000
0x03 == compact encoding:     0x03000000
0x03 == compact encoding:     0x03000000
