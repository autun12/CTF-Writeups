# Copyright © 2024 Peace-Maker <peacemakerctf@gmail.com>
# SPDX-License-Identifier: BSD-3
# Compatibility header with pre v6 API
from .arm64_const import *
