## Python cstest

This is the equivalent testing tool to `suite/cstest/`. It consumes the `yaml` test files
in `<repo-root>/tests/` and reports the results.
