__notice(pl_mpeg_notice, "\
PL_MPEG (MIT License)\n\
Copyright(c) 2019 Dominic Szablewski\n\
https://phoboslab.org");

long plmpegdecode_latency_;

#define PL_MPEG_IMPLEMENTATION
#include "pl_mpeg.h"
