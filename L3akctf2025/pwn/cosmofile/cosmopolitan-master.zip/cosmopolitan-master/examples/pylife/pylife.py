import sys
sys.exit(42)
