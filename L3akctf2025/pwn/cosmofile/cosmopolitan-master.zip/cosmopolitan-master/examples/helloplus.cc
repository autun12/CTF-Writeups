#include "ctl/ostream.h"

int main(int argc, char* argv[]) {
  ctl::cout << "hello world\n";
  return 0;
}
