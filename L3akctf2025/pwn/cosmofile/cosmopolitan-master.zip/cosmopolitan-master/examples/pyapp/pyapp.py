def main():
  print('cosmopolitan is cool!')
if __name__ == '__main__':
  main()
